public class ProductoInputHandler {

    private final Control controlador = new Control();
    protected String nombre;


    public Producto obtenerDatosProducto() {

        System.out.print("Por favor ingrese el nombre del producto: ");
        String nombre = controlador.controlNoNulo("nombre del producto");

        System.out.print("Por favor ingrese el ID del producto: ");
        String id = controlador.control_id();

        System.out.println("Por favor ingrese la categoria del producto: ");
        Enum categoria = controlador.controlCategoria();

        System.out.print("Por favor ingrese el precio del producto: ");
        int precio = controlador.control_precio();

        System.out.print("Por favor ingrese la cantidad de productos: ");
        int cantidad = controlador.controlCantidadProductos();


        return new Producto(nombre, id,(Categorias) categoria, precio, cantidad);
    }

    public void agregarProducto(Catalogo catalogo, Producto producto){
        catalogo.agregarProducto(producto);

    }
}
