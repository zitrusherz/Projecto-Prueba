public enum Categorias {
    MANGA,
    FIGURA,
    ACCESORIO
}
