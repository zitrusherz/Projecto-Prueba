// Purpose: Contiene los metodos de control de datos ingresados por el usuario.
// Date: 23/09/2020


import java.util.ArrayList;
import java.util.Scanner;
public class Control {

    Scanner sc = new Scanner(System.in);

    //Metodos de control de datos ingresados por el usuario
    //Metodo de control de producto
    public String control_id(){
        String id_producto = sc.next();
        while(id_producto.length() < 6 || id_producto.length() > 8){
            System.out.println("El ID/codigo del producto no es valido, ingreselo nuevamente: ");
            id_producto = sc.next();
            System.out.println();
        }return id_producto;

    }
    public int control_precio(){
        int precio = sc.nextInt();
        while(precio <= 0){
            System.out.println("El precio no puede ser menor o igual a 0.\nPor favor ingreselo nuevamente: ");
            precio = sc.nextInt();

        }
        return precio;
    }
    //Metodo de control de categoria
    public Enum controlCategoria(){


        for(Categorias categoria: Categorias.values()){
            System.out.println(categoria.ordinal() + 1 + ". " + categoria);
        }
        System.out.println("Por favor ingrese el numero correspondiente a la categoria del producto: ");
        int eleccion = sc.nextInt();
        while(eleccion < 0 || eleccion > 4){
            System.out.println("La eleccion no es valida, por favor intentelo nuevamente: ");
            eleccion = sc.nextInt();
            System.out.println();
        }
        Enum categoria = Categorias.values()[eleccion - 1];
        return categoria;
    }

    public int controlCantidadProductos(){
        int cantidadProducto = sc.nextInt();
        while (cantidadProducto <= 0){
            System.out.println("La cantidad de productos no puede ser menor o igual a 0.\nPor favor ingresela nuevamente: ");
            cantidadProducto = sc.nextInt();
            System.out.println();
        }
        return cantidadProducto;
    }
    //Metodo de control de cliente
    public String controlTelefono(){
        String telefono_cliente = sc.next();
        while(telefono_cliente.length() != 8){
            System.out.println("Numero ingresado no es valido.\nPor favor ingreselo nuevamente: ");
            telefono_cliente = sc.next();
            System.out.println();
        }
        return telefono_cliente;

    }

    public String controlCorreo(){
        String correo_cliente = sc.next();
        while(!correo_cliente.contains("@")){
            System.out.print("El correo ingresado no es valido, intentelo nuevamente: ");
            correo_cliente = sc.nextLine();
            System.out.println();
        }
        return correo_cliente;
    }
    public String controlNoNulo(String tipo_de_dato){

        String dato = sc.next();
        while(dato == null || dato.equals(" ")){
            System.out.printf("Dato ingresado necesario, el %s puede estar vacio.\nPor favor ingrese tu %s: ", tipo_de_dato, tipo_de_dato);
            dato = sc.next();
            System.out.println();
        }
        return dato;

    }
    public String controlRun(String tipoDeDato){

        String dato = sc.next();
        while(dato.length() < 7 || dato.length() > 8){
            System.out.printf("Dato ingresado necesario, el %s es erroneo.\nPor favor ingresa tu %s: ", tipoDeDato, tipoDeDato);
            dato = sc.next();
            System.out.println();
        }
        return dato;
    }
    public String controlDv(String tipo_de_dato){

        String dato = sc.next();
        while(dato.length() != 1 || dato.equals(" ")){
            System.out.printf("Dato ingresado necesario, el %s es erroneo.\nPor favor ingresa tu %s: ", tipo_de_dato, tipo_de_dato);
            dato = sc.next();
            System.out.println();
        }
        return dato;

    }
    //Metodo de control del menu
    public int controlMenu(){
        int eleccion = sc.nextInt();
        while(eleccion < 0 || eleccion >= 3){
            System.out.print("Elección no es valida, intente nuevamente: ");
            eleccion = sc.nextInt();
            System.out.println();
        }return eleccion;

    }
        public Catalogo controlNoNullListaProductos(){
        int contador = 0;
        int eleccion;
        ProductoInputHandler productoInputHandler = new ProductoInputHandler();

        while(contador == 0){

            System.out.println("No hay productos para comprar, por favor ingrese 1 para agregar un producto al catalogo, o ingrese 0 para salir del programa:");
            eleccion = sc.nextInt();
            System.out.println();
            if(eleccion == 0){
                return null;
            }else if(eleccion == 1){
            System.out.println("Bienvenido a We are.\nPor favor ingrese los datos del producto que desea agregar al catalogo");
            Producto nuevoProducto = productoInputHandler.obtenerDatosProducto();
            Catalogo catalogo = new Catalogo(nuevoProducto);
            System.out.println("El producto ha sido agregado al catalogo");
            contador = 1;
            return catalogo;
            }
        }
            return null;
    }

    public int control_num_products(int num_of_products){
        int input_usuario = sc.nextInt();
        while (input_usuario < 0 || input_usuario > num_of_products){
            System.out.println("El numero del producto no es valido, por favor intentelo nuevamente: ");
            input_usuario = sc.nextInt();
            System.out.println();
        }
        return input_usuario;

    }

    public void controlStockProductos(int cantidadAComprar, int numProducto){
        Catalogo catalogo = new Catalogo();

        while(cantidadAComprar > catalogo.getCantidadProducto(numProducto)){
            System.out.println("La cantidad de productos a comprar es mayor a la cantidad de productos en stock\nPor favor ingrese una cantidad valida: ");
            cantidadAComprar = sc.nextInt();
            System.out.println();
        }

    }

}

