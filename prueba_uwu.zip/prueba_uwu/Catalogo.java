import java.util.ArrayList;

public class Catalogo {
    private ArrayList<Producto> catalogo = new ArrayList<>();

    public Catalogo(Producto producto){
        catalogo.add(producto);
        this.catalogo = catalogo;
    }

    public Catalogo() {
        this.catalogo = catalogo;
    }

    public void agregarProducto(Producto producto){
        catalogo.add(producto);
    }

    public ArrayList getCatalogo(){

        return catalogo;
    }

    public int getListaProductos(ArrayList<Producto> catalogo){
        System.out.println("El catalogo de productos es el siguiente: ");

        int num_of_products = 0;
        for(int o = 0; o < catalogo.size(); o++){
            System.out.println("Producto N° " + o + 1);
            num_of_products += 1;
            System.out.println(this.catalogo.get(o));
            System.out.print(";");
            System.out.println("----------------------------------");
        }
        return num_of_products;
    }

    public int getCantidadProducto(int numProducto){

        return catalogo.get(numProducto).getCantidad();
    }

    public void setCantidadProductoNueva(int numProducto, int cantidadComprada){
        catalogo.get(numProducto).setCantidad(getCantidadProducto(numProducto) - cantidadComprada);
    }



}
