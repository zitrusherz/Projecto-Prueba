import java.util.Scanner;
import java.util.ArrayList;
public class Menu {
    ArrayList<Producto> catalogoDelMenu = new ArrayList<>();
    public Pedido menuCliente(Catalogo catalogo){
        Scanner sc = new Scanner(System.in);
        ClienteInputHandler clienteInputHandler = new ClienteInputHandler();
        Control controlador = new Control();


        Cliente nuevoCliente = clienteInputHandler.obtenerDatosCliente();
        System.out.println("Bienvenido " + nuevoCliente.toString() + " a We are");
        catalogoDelMenu = catalogo.getCatalogo();
        catalogo.getListaProductos(catalogoDelMenu);
        System.out.println("Por favor ingrese el numero correspondiente de los productos que desea comprar, para terminar ingrese 0");
        int terminar_elecc_products = -1;
        while (terminar_elecc_products != 0) {
            int numeroProducto = controlador.control_num_products(catalogoDelMenu.size());
            System.out.print("Por favor ingrese la cantidad de productos que desea comprar: ");
            int cantidadProducto = controlador.controlCantidadProductos();
            controlador.controlStockProductos(cantidadProducto, numeroProducto);
            catalogo.setCantidadProductoNueva(numeroProducto, cantidadProducto);
            System.out.println("Si desea terminar de elegir productos ingrese 0, si desea seguir eligiendo productos ingrese 1");
            terminar_elecc_products = sc.nextInt();
            System.out.println();

        }
        sc.close();
    }

    public Catalogo colaboradorMenu(){
        ProductoInputHandler productoInputHandler = new ProductoInputHandler();
        System.out.println("Bienvenido a We are.\nPor favor ingrese los datos del producto que desea agregar al catalogo:");
        Producto nuevoProducto = productoInputHandler.obtenerDatosProducto();
        Catalogo catalogo = new Catalogo(nuevoProducto);
        System.out.println("El producto ha sido agregado al catalogo");
        return catalogo;
    }
    public int runMenu() {

        int exit = -1;
        Scanner sc = new Scanner(System.in);
        Control controlador = new Control();
        Catalogo catalogo;

        ProductoInputHandler productoInputHandler = new ProductoInputHandler();
        if(controlador.controlNoNullListaProductos() == null){
            System.out.println("Gracias por usar We are");
            System.exit(0);
            catalogo = controlador.controlNoNullListaProductos();
            catalogoDelMenu = catalogo.getCatalogo();
            return 0;
        }else{
            catalogo = controlador.controlNoNullListaProductos();
            catalogoDelMenu = catalogo.getCatalogo();
        }

        while (exit != 0) {

            System.out.println("Bienvenido al menú de We are, por favor seleccione alguna de las siguientes alternativas\n"
                    + "Si usted es cliente ingrese 1\n"
                    + "Si usted es colaborador de We are ingrese 2\n"
                    + "Si desea salir del menú ingrese 0");

            exit = controlador.controlMenu();


            switch (exit) {

                case 1:
                    menuCliente(catalogoDelMenu);

                    break;
            //-------------------------------------------------------------------------------------------------------------------------------------------------

                case 2:
                    colaboradorMenu();

                    break;
            }
        }return 0;
    }
        public static void main (String[]args){
            Scanner sc = new Scanner(System.in);
            Control controlador = new Control();
            Catalogo catalogo = new Catalogo();
            ClienteInputHandler clienteInputHandler = new ClienteInputHandler();
            ProductoInputHandler productoInputHandler = new ProductoInputHandler();
            Menu menuRuning = new Menu();
            menuRuning.runMenu();

            sc.close();
        }

    }



