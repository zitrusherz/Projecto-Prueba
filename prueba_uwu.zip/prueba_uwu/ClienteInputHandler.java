
public class ClienteInputHandler{
    private final Control controlador = new Control();

    public Cliente obtenerDatosCliente() {
        System.out.print("Por favor ingrese su nombre: ");
        String nombre = controlador.controlNoNulo("nombre");

        System.out.print("Por favor ingrese su apellido: ");
        String apellido = controlador.controlNoNulo("apellido");

        System.out.print("Por favor ingrese su correo: ");
        String correo = controlador.controlCorreo();

        System.out.print("Por favor ingrese su telefono: ");
        String telefono = controlador.controlTelefono();

        System.out.print("Por favor ingrese su run(sin digito verificador): ");
        String run = controlador.controlRun("run");

        System.out.print("Por favor ingrese su digito verificador: ");
        String dv = controlador.controlDv("dv");

        return new Cliente(nombre, apellido, correo, telefono, run, dv);
    }


}